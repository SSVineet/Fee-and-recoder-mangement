/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smpic;

/**
 *
 * @author MAURYA
 */
public class Smpic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Loginform obj1 = new Loginform();
        obj1.setVisible(true);
      //  RGFORM obj1 = new RGFORM();
       // Mainpage obj = new Mainpage();
       // obj.setVisible(true);
       // Section obj = new Section();
       // obj.setVisible(true);
        //obj1.setVisible(true);
       
    }
    
}
