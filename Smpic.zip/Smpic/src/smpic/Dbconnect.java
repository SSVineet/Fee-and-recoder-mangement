/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smpic;

import com.mysql.jdbc.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author MAURYA
 */
public class Dbconnect {
    private Connection con;
    private statement st;
    private ResultSet rs;
    public void Dbconnect(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con  =(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/sonoo","root","");  
        st = (statement) con.createStatement();
        
    
    }catch(Exception ex){
        System.out.println("Error"+ex);
    
    }
    
    }
    public void setData(){
        try{
        String query = " ";
        
        } catch(Exception ex ){
        
        }
     
    }
    
    
}
